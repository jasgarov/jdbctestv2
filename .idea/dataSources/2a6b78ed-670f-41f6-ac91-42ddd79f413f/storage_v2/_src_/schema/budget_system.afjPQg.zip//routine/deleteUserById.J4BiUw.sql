create
  definer = root@localhost procedure deleteUserById(IN u_id int)
BEGIN
  DELETE FROM users WHERE id=u_id;
END;

