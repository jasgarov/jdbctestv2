create
  definer = root@localhost procedure getUserById(IN u_id int, OUT u_login varchar(20), OUT u_password varchar(20))
BEGIN
  SELECT login INTO u_login
  FROM users
  WHERE id = u_id;

  SELECT password INTO u_password
  FROM users
  WHERE id = u_id;
END;

