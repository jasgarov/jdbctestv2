create
  definer = root@localhost procedure updateUserInfoById(IN u_id int, IN new_login varchar(20), IN new_password varchar(20))
BEGIN
  UPDATE users
  SET login = new_login
  WHERE id = u_id;

  UPDATE users
  SET password = new_password
  WHERE id = u_id;
END;

